package dev.lumen.gui;

import java.util.ArrayList;
import java.util.List;
import java.util.function.IntConsumer;

import dev.lumen.core.Category;
import dev.lumen.core.Config;
import dev.lumen.core.Module;
import dev.lumen.core.Modules;
import dev.lumen.core.Setting;
import dev.lumen.core.Theme;
import dev.lumen.hud.HudRenderer;
import dev.lumen.hud.HudWidget;
import dev.lumen.util.Anim;
import dev.lumen.util.Draw;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.client.input.KeyEvent;
import net.minecraft.client.input.MouseButtonEvent;
import net.minecraft.network.chat.Component;
import net.minecraft.util.Mth;
import org.joml.Matrix3x2fStack;
import org.lwjgl.glfw.GLFW;

/**
 * Меню на Right Shift. Левый клик по модулю — включить/выключить,
 * правый клик — раскрыть настройки. HUD-элементы можно таскать мышью за пределами панели.
 */
public final class MenuScreen extends Screen {
	private static final int PW = 392, PH = 244, SB = 100;
	private static final int CX = SB + 8, CW = PW - CX - 12, VY0 = 38, VY1 = PH - 10;
	private static final int CARD = 26, ROW = 18;

	private static Category lastCat = Category.HUD;

	private interface FloatCb { void run(float v); }

	private record Region(float x, float y, float w, float h, IntConsumer click, FloatCb drag) {
		boolean has(float px, float py) {
			return px >= x && px <= x + w && py >= y && py <= y + h;
		}
	}

	private final List<Region> regions = new ArrayList<>();
	private Category cat = lastCat;
	private float open, scale = 1f, alpha = 1f;
	private float scroll, scrollTarget, contentH, catY = -1f;
	private Region activeDrag;
	private HudWidget dragWidget;
	private float dragOx, dragOy;

	public MenuScreen() {
		super(Component.literal("Lumen"));
	}

	public HudWidget draggingWidget() {
		return dragWidget;
	}

	@Override
	public boolean isPauseScreen() {
		return false;
	}

	@Override
	public void removed() {
		Config.save();
	}

	// ───────────────────────── координаты ─────────────────────────

	private float lx(double mx) {
		return (float) ((mx - width / 2.0) / scale + PW / 2.0);
	}

	private float ly(double my) {
		return (float) ((my - height / 2.0) / scale + PH / 2.0);
	}

	private int c(int color) {
		return Draw.a(color, alpha);
	}

	private static boolean in(float px, float py, float x, float y, float w, float h) {
		return px >= x && px <= x + w && py >= y && py <= y + h;
	}

	/** Регистрирует кликабельную зону, обрезанную по видимой области списка. */
	private void zone(float x, float y, float w, float h, IntConsumer click, FloatCb drag) {
		float y1 = Math.max(y, VY0), y2 = Math.min(y + h, VY1);
		if (y2 <= y1) return;
		regions.add(new Region(x, y1, w, y2 - y1, click, drag));
	}

	// ───────────────────────── рендер ─────────────────────────

	@Override
	public void render(GuiGraphics g, int mx, int my, float partial) {
		Anim.tick();
		open = Anim.approach(open, 1f, 13f);
		alpha = open;

		g.fill(0, 0, width, height, Draw.a(0xFF000000, 0.40f * alpha));

		float fit = Math.min(1f, Math.min(width / (PW + 16f), height / (PH + 16f)));
		scale = fit * (0.9f + 0.1f * Anim.easeOut(open));
		float lx = lx(mx), ly = ly(my);

		regions.clear();
		Matrix3x2fStack ps = g.pose();
		ps.pushMatrix();
		ps.translate(width / 2f, height / 2f);
		ps.scale(scale, scale);
		ps.translate(-PW / 2f, -PH / 2f);
		drawPanel(g, lx, ly);
		ps.popMatrix();

		String hint = "Drag HUD elements outside the menu to move them";
		Draw.text(g, hint, (width - Draw.width(hint) * 0.8f) / 2f, height - 12, 0.8f, c(0xFFB8C0CE), true);
	}

	private void drawPanel(GuiGraphics g, float lx, float ly) {
		Draw.shadow(g, 0, 0, PW, PH, 7, alpha);
		Draw.rounded(g, 0, 0, PW, PH, 7, c(0xF2111419));

		// ── боковая панель ──
		Draw.rounded(g, 6, 6, SB - 6, PH - 12, 5, c(0xFF0B0E13));
		String logo = "LUMEN";
		float lxx = 16;
		for (int i = 0; i < logo.length(); i++) {
			String ch = String.valueOf(logo.charAt(i));
			Draw.text(g, ch, lxx, 16, 1.5f, c(Draw.lerp(Theme.accent(), Theme.accent2(), i / 4f)), true);
			lxx += Draw.width(ch) * 1.5f + 1f;
		}
		Draw.text(g, "VISUALS", 17, 31, 0.75f, c(Theme.MUTED), false);

		float targetY = 50 + cat.ordinal() * 24;
		catY = catY < 0 ? targetY : Anim.approach(catY, targetY, 16f);
		Draw.rounded(g, 10, catY, SB - 14, 20, 4, c(Draw.a(Theme.accent(), 0.18f)));
		g.fill(10, Math.round(catY) + 4, 12, Math.round(catY) + 16, c(Theme.accent()));

		for (Category k : Category.values()) {
			float y = 50 + k.ordinal() * 24;
			boolean hov = in(lx, ly, 10, y, SB - 14, 20);
			int col = k == cat ? Theme.TEXT : hov ? 0xFFC7CDD8 : Theme.MUTED;
			Draw.text(g, k.label, 22, y + 6, c(col));
			regions.add(new Region(10, y, SB - 14, 20, b -> setCat(k), null));
		}
		Draw.text(g, "RShift to close", 14, PH - 20, 0.75f, c(0xFF5B6475), false);

		// ── заголовок ──
		Draw.text(g, cat.label, CX, 13, 1.4f, c(Theme.TEXT), true);
		String tip = "LMB toggle  |  RMB settings";
		Draw.text(g, tip, CX + CW - Draw.width(tip) * 0.75f, 17, 0.75f, c(Theme.MUTED), false);
		g.fill(CX, 31, CX + CW, 32, c(0x14FFFFFF));

		// ── список модулей ──
		float maxScroll = Math.max(0f, contentH - (VY1 - VY0));
		scrollTarget = Mth.clamp(scrollTarget, 0f, maxScroll);
		scroll = Anim.approach(scroll, scrollTarget, 16f);

		g.enableScissor(CX - 2, VY0, CX + CW + 2, VY1);
		float yy = VY0 - scroll;
		for (Module m : Modules.ALL) {
			if (m.category != cat) continue;
			m.guiToggle = Anim.approach(m.guiToggle, m.enabled ? 1f : 0f, 16f);
			m.guiExpand = Anim.approach(m.guiExpand, m.expanded ? 1f : 0f, 14f);
			float h = CARD + (m.settings.isEmpty() ? 0 : Math.round(m.guiExpand * (m.settings.size() * ROW + 6)));
			if (yy + h > VY0 - 2 && yy < VY1 + 2) drawCard(g, m, CX, yy, CW, h, lx, ly);
			yy += h + 6;
		}
		contentH = yy + scroll - VY0;
		g.disableScissor();

		if (maxScroll > 1f) {
			float trackH = VY1 - VY0;
			float barH = Math.max(14f, trackH * trackH / contentH);
			float by = VY0 + (trackH - barH) * (scroll / maxScroll);
			Draw.rounded(g, CX + CW + 4, by, 2, barH, 1, c(Draw.a(Theme.accent(), 0.7f)));
		}
	}

	private void setCat(Category k) {
		cat = k;
		lastCat = k;
		scroll = scrollTarget = 0f;
		contentH = 0f;
	}

	// ───────────────────────── карточка модуля ─────────────────────────

	private void drawCard(GuiGraphics g, Module m, float x, float y, float w, float h, float lx, float ly) {
		boolean hov = in(lx, ly, x, y, w, CARD) && ly >= VY0 && ly <= VY1;
		Draw.rounded(g, x, y, w, h, 5, c(hov ? 0xFF1D222C : 0xFF171B23));
		if (m.guiToggle > 0.01f) {
			g.fill(Math.round(x), Math.round(y) + 6, Math.round(x) + 2, Math.round(y) + CARD - 6,
				c(Draw.a(Theme.accent(), m.guiToggle)));
		}
		Draw.text(g, m.name, x + 10, y + 5, c(Theme.TEXT));
		Draw.text(g, m.desc, x + 10, y + 16, 0.72f, c(Theme.MUTED), false);

		float sx = x + w - 34;
		if (m.toggleable) drawSwitch(g, sx, y + 7, 24, 12, m.guiToggle, alpha);
		if (!m.settings.isEmpty()) {
			Draw.text(g, m.expanded ? "v" : ">", (m.toggleable ? sx - 14 : x + w - 16), y + 9, c(Theme.MUTED));
		}
		zone(x, y, w, CARD, b -> {
			if (b == 1 || !m.toggleable) {
				if (!m.settings.isEmpty()) m.expanded = !m.expanded;
			} else if (b == 0) {
				m.toggle();
			}
		}, null);

		if (m.guiExpand > 0.02f && !m.settings.isEmpty()) {
			g.enableScissor(Math.round(x), Math.round(Math.max(y, VY0)), Math.round(x + w), Math.round(Math.min(y + h, VY1)));
			float ea = m.guiExpand * alpha;
			for (int i = 0; i < m.settings.size(); i++) {
				drawSetting(g, m.settings.get(i), x, y + CARD + 2 + i * ROW, w, ea, lx, ly, m.guiExpand > 0.85f);
			}
			g.disableScissor();
		}
	}

	private static void drawSwitch(GuiGraphics g, float x, float y, float w, float h, float t, float al) {
		Draw.rounded(g, x, y, w, h, (int) (h / 2), Draw.a(Draw.lerp(0xFF2B313D, Theme.accent(), t), al));
		float k = h - 4;
		float kx = x + 2 + (w - k - 4) * t;
		Draw.rounded(g, kx, y + 2, k, k, (int) (k / 2), Draw.a(0xFFFFFFFF, al));
	}

	private void drawSetting(GuiGraphics g, Setting s, float x, float ry, float w, float al, float lx, float ly, boolean live) {
		Draw.text(g, s.name, x + 12, ry + 5, Draw.a(Theme.MUTED, al));
		switch (s.type) {
			case BOOL -> {
				s.anim = Anim.approach(s.anim, s.bool ? 1f : 0f, 18f);
				drawSwitch(g, x + w - 34, ry + 3, 20, 10, s.anim, al);
				if (live) zone(x, ry, w, ROW, b -> s.bool = !s.bool, null);
			}
			case NUM -> {
				float tx = x + w - 124, tw = 76, ty = ry + 7;
				float frac = (float) ((s.num - s.min) / (s.max - s.min));
				Draw.rounded(g, tx, ty, tw, 3, 1, Draw.a(0xFF2B313D, al));
				Draw.rounded(g, tx, ty, Math.max(2f, tw * frac), 3, 1, Draw.a(Theme.accent(), al));
				Draw.rounded(g, tx + tw * frac - 3, ty - 2, 6, 7, 3, Draw.a(0xFFFFFFFF, al));
				String v = s.display();
				Draw.text(g, v, x + w - 10 - Draw.width(v), ry + 5, Draw.a(Theme.TEXT, al));
				if (live) {
					zone(tx - 4, ry, tw + 8, ROW, b -> {},
						mxl -> s.setNum(s.min + Mth.clamp((mxl - tx) / tw, 0f, 1f) * (s.max - s.min)));
				}
			}
			case MODE -> {
				float bx = x + w - 100, bw = 90;
				Draw.rounded(g, bx, ry + 2, bw, 14, 3, Draw.a(0xFF232934, al));
				String mn = s.modeName();
				Draw.text(g, mn, bx + (bw - Draw.width(mn)) / 2f, ry + 5, Draw.a(Theme.TEXT, al));
				Draw.text(g, "<", bx + 4, ry + 5, Draw.a(Theme.MUTED, al * 0.8f));
				Draw.text(g, ">", bx + bw - 9, ry + 5, Draw.a(Theme.MUTED, al * 0.8f));
				if (live) zone(bx, ry, bw, ROW, b -> s.cycle(b == 1 ? -1 : 1), null);
			}
		}
	}

	// ───────────────────────── ввод ─────────────────────────

	@Override
	public boolean mouseClicked(MouseButtonEvent e, boolean doubleClick) {
		float lx = lx(e.x()), ly = ly(e.y());
		int b = e.button();

		for (int i = regions.size() - 1; i >= 0; i--) {
			Region r = regions.get(i);
			if (!r.has(lx, ly)) continue;
			r.click().accept(b);
			if (r.drag() != null && b == 0) {
				activeDrag = r;
				r.drag().run(lx);
			}
			return true;
		}
		if (in(lx, ly, 0, 0, PW, PH)) return true;

		List<HudWidget> ws = HudRenderer.widgets();
		for (int i = ws.size() - 1; i >= 0; i--) {
			HudWidget w = ws.get(i);
			if (w.module.enabled && w.contains(e.x(), e.y())) {
				dragWidget = w;
				dragOx = (float) e.x() - w.px;
				dragOy = (float) e.y() - w.py;
				return true;
			}
		}
		return super.mouseClicked(e, doubleClick);
	}

	@Override
	public boolean mouseDragged(MouseButtonEvent e, double dx, double dy) {
		if (activeDrag != null && activeDrag.drag() != null) {
			activeDrag.drag().run(lx(e.x()));
			return true;
		}
		if (dragWidget != null) {
			dragWidget.moveTo((float) e.x() - dragOx, (float) e.y() - dragOy, width, height);
			return true;
		}
		return super.mouseDragged(e, dx, dy);
	}

	@Override
	public boolean mouseReleased(MouseButtonEvent e) {
		boolean had = activeDrag != null || dragWidget != null;
		activeDrag = null;
		dragWidget = null;
		if (had) Config.save();
		return had || super.mouseReleased(e);
	}

	@Override
	public boolean mouseScrolled(double mx, double my, double sx, double sy) {
		scrollTarget -= (float) sy * 24f;
		return true;
	}

	@Override
	public boolean keyPressed(KeyEvent e) {
		if (e.key() == GLFW.GLFW_KEY_RIGHT_SHIFT) {
			onClose();
			return true;
		}
		return super.keyPressed(e);
	}
}
