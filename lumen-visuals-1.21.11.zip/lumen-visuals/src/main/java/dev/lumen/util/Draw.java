package dev.lumen.util;

import dev.lumen.core.Theme;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.util.Mth;
import org.joml.Matrix3x2fStack;

/** Мини-библиотека рисования: скруглённые панели, текст, цвета. */
public final class Draw {
	private static final int[][] INSET = new int[17][];

	private Draw() {}

	private static int[] inset(int r) {
		int[] a = INSET[r];
		if (a == null) {
			a = new int[r];
			for (int i = 0; i < r; i++) {
				double dy = r - i - 0.5;
				double dx = Math.sqrt(r * (double) r - dy * dy);
				a[i] = (int) Math.round(r - dx);
			}
			INSET[r] = a;
		}
		return a;
	}

	/** Умножает альфу цвета на alpha. */
	public static int a(int color, float alpha) {
		int al = Math.round(((color >>> 24) & 255) * Mth.clamp(alpha, 0f, 1f));
		return (al << 24) | (color & 0xFFFFFF);
	}

	public static int lerp(int c1, int c2, float t) {
		t = Mth.clamp(t, 0f, 1f);
		int out = 0;
		for (int s = 0; s <= 24; s += 8) {
			int x = (c1 >>> s) & 255, y = (c2 >>> s) & 255;
			out |= (Math.round(x + (y - x) * t) & 255) << s;
		}
		return out;
	}

	public static int hp(float f) {
		f = Mth.clamp(f, 0f, 1f);
		return f > 0.5f ? lerp(0xFFFACC15, 0xFF4ADE80, (f - 0.5f) * 2f) : lerp(0xFFEF4444, 0xFFFACC15, f * 2f);
	}

	public static void rounded(GuiGraphics g, float fx, float fy, float fw, float fh, int r, int c) {
		if ((c >>> 24) < 2) return;
		int x = Math.round(fx), y = Math.round(fy), w = Math.round(fw), h = Math.round(fh);
		if (w <= 0 || h <= 0) return;
		r = Math.min(16, Math.min(r, Math.min(w, h) / 2));
		if (r <= 0) {
			g.fill(x, y, x + w, y + h, c);
			return;
		}
		int[] in = inset(r);
		g.fill(x, y + r, x + w, y + h - r, c);
		for (int i = 0; i < r; i++) {
			g.fill(x + in[i], y + i, x + w - in[i], y + i + 1, c);
			g.fill(x + in[i], y + h - 1 - i, x + w - in[i], y + h - i, c);
		}
	}

	/** Мягкая тень под большой панелью. */
	public static void shadow(GuiGraphics g, float x, float y, float w, float h, int r, float alpha) {
		for (int k = 3; k >= 1; k--) {
			rounded(g, x - k, y - k + 1, w + k * 2, h + k * 2, r + k, a(0xFF000000, 0.06f * alpha));
		}
	}

	/** Стеклянная панель с тонкой акцентной линией сверху. */
	public static void panel(GuiGraphics g, float x, float y, float w, float h, float alpha) {
		int r = Theme.radius();
		rounded(g, x, y, w, h, r, Theme.bg(alpha));
		int ix = Math.round(x), iy = Math.round(y), iw = Math.round(w);
		if (iw > r * 2 + 2) {
			g.fill(ix + r, iy, ix + iw - r, iy + 1, a(Theme.accent(), 0.85f * alpha));
		}
	}

	public static int width(String s) {
		return Minecraft.getInstance().font.width(s);
	}

	public static void text(GuiGraphics g, String s, float x, float y, int color) {
		text(g, s, x, y, 1f, color, true);
	}

	public static void text(GuiGraphics g, String s, float x, float y, float scale, int color, boolean shadow) {
		if ((color >>> 24) < 8 || s.isEmpty()) return;
		var font = Minecraft.getInstance().font;
		if (scale == 1f) {
			g.drawString(font, s, Math.round(x), Math.round(y), color, shadow);
			return;
		}
		Matrix3x2fStack m = g.pose();
		m.pushMatrix();
		m.translate(x, y);
		m.scale(scale, scale);
		g.drawString(font, s, 0, 0, color, shadow);
		m.popMatrix();
	}

	public static void textRight(GuiGraphics g, String s, float right, float y, float scale, int color) {
		text(g, s, right - width(s) * scale, y, scale, color, true);
	}

	/** Горизонтальный бар с фоном. */
	public static void bar(GuiGraphics g, float x, float y, float w, float h, float frac, int color, float alpha) {
		rounded(g, x, y, w, h, 1, a(0xFFFFFFFF, 0.12f * alpha));
		float fw = w * Mth.clamp(frac, 0f, 1f);
		if (fw >= 1f) rounded(g, x, y, fw, h, 1, a(color, alpha));
	}
}
