package dev.lumen.util;

import net.minecraft.util.Mth;

/** Покадровая анимация: dt в секундах, экспоненциальное сглаживание, easing. */
public final class Anim {
	private static long last = System.nanoTime();
	public static float dt = 0.016f;

	private Anim() {}

	/** Безопасно вызывать несколько раз за кадр. */
	public static void tick() {
		long n = System.nanoTime();
		float d = (n - last) / 1_000_000_000f;
		if (d > 0.0005f) {
			dt = Math.min(d, 0.1f);
			last = n;
		}
	}

	public static float approach(float cur, float target, float speed) {
		float v = cur + (target - cur) * (1f - (float) Math.exp(-speed * dt));
		return Math.abs(target - v) < 0.0005f ? target : v;
	}

	public static float easeOut(float t) {
		t = Mth.clamp(t, 0f, 1f);
		float u = 1f - t;
		return 1f - u * u * u;
	}

	public static float smooth(float t) {
		t = Mth.clamp(t, 0f, 1f);
		return t * t * (3f - 2f * t);
	}

	public static float easeOutBack(float t) {
		t = Mth.clamp(t, 0f, 1f);
		float c1 = 1.70158f, c3 = c1 + 1f, u = t - 1f;
		return 1f + c3 * u * u * u + c1 * u * u;
	}
}
