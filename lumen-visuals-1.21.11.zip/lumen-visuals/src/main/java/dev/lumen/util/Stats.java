package dev.lumen.util;

/** Свой счётчик FPS, чтобы не зависеть от внутренних методов клиента. */
public final class Stats {
	public static int fps;
	private static int frames;
	private static long stamp = System.currentTimeMillis();

	private Stats() {}

	public static void frame() {
		frames++;
		long n = System.currentTimeMillis();
		if (n - stamp >= 1000) {
			fps = (int) (frames * 1000L / (n - stamp));
			frames = 0;
			stamp = n;
		}
	}
}
