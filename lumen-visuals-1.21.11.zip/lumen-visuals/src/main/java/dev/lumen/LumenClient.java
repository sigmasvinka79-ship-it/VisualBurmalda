package dev.lumen;

import com.mojang.blaze3d.platform.InputConstants;
import dev.lumen.core.Config;
import dev.lumen.gui.MenuScreen;
import dev.lumen.hud.HudRenderer;
import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientLifecycleEvents;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.keybinding.v1.KeyBindingHelper;
import net.minecraft.client.KeyMapping;
import net.minecraft.resources.Identifier;
import org.lwjgl.glfw.GLFW;

public final class LumenClient implements ClientModInitializer {
	public static final String ID = "lumen";
	public static KeyMapping OPEN_MENU;

	@Override
	public void onInitializeClient() {
		Config.load();

		KeyMapping.Category category = KeyMapping.Category.register(Identifier.fromNamespaceAndPath(ID, "main"));
		OPEN_MENU = KeyBindingHelper.registerKeyBinding(new KeyMapping(
			"key.lumen.open_menu",
			InputConstants.Type.KEYSYM,
			GLFW.GLFW_KEY_RIGHT_SHIFT,
			category
		));

		HudRenderer.init();

		ClientTickEvents.END_CLIENT_TICK.register(mc -> {
			while (OPEN_MENU.consumeClick()) {
				if (mc.level != null && mc.screen == null) mc.setScreen(new MenuScreen());
			}
		});
		ClientLifecycleEvents.CLIENT_STOPPING.register(mc -> Config.save());
	}
}
