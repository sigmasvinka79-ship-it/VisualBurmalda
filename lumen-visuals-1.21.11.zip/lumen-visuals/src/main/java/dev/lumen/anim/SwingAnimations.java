package dev.lumen.anim;

import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.math.Axis;
import dev.lumen.core.Modules;
import net.minecraft.util.Mth;
import net.minecraft.world.entity.HumanoidArm;

/**
 * Анимации взмаха в первом лице. Полностью клиентские: меняется только матрица
 * отрисовки предмета в руке. Каждая анимация возвращается в identity при swing = 0 и 1.
 */
public final class SwingAnimations {
	private SwingAnimations() {}

	private static void rx(PoseStack p, float d) { p.mulPose(Axis.XP.rotationDegrees(d)); }
	private static void ry(PoseStack p, float d) { p.mulPose(Axis.YP.rotationDegrees(d)); }
	private static void rz(PoseStack p, float d) { p.mulPose(Axis.ZP.rotationDegrees(d)); }

	/** @return true, если ванильное преобразование нужно отменить. */
	public static boolean apply(PoseStack p, HumanoidArm arm, float swing) {
		if (!Modules.SWING.enabled) return false;
		int mode = Modules.SW_MODE.mode;
		if (mode == 0) return false;
		if (swing <= 0f) return true;

		float k = Modules.SW_POWER.f();
		int side = arm == HumanoidArm.RIGHT ? 1 : -1;
		float w = Mth.sin(swing * Mth.PI);
		float s = Mth.sin(Mth.sqrt(swing) * Mth.PI);
		float e = swing * swing * (3f - 2f * swing);

		switch (mode) {
			case 1 -> { // Smooth
				ry(p, side * (45f - 8f * s * k));
				rz(p, side * s * -14f * k);
				rx(p, s * -62f * k);
				ry(p, side * -45f);
			}
			case 2 -> { // Slash
				ry(p, side * 45f);
				rz(p, side * -70f * w * k);
				rx(p, -18f * w * k);
				ry(p, side * (-45f + 38f * w * k));
			}
			case 3 -> { // Slide
				p.translate(side * 0.06f * w * k, -0.12f * w * k, -0.65f * w * k);
				rx(p, -12f * w * k);
			}
			case 4 -> { // Block
				p.translate(side * -0.12f * w * k, 0.08f * w * k, 0f);
				ry(p, side * 28f * w * k);
				rz(p, side * -22f * w * k);
				rx(p, (-52f * w - 26f * s) * k);
			}
			case 5 -> { // Spin
				rx(p, -25f * w * k);
				rz(p, side * 360f * e);
			}
			case 6 -> { // Poke
				p.translate(0f, 0.02f * w * k, -0.85f * w * k);
				rx(p, -6f * w * k);
				ry(p, side * 8f * w * k);
			}
			case 7 -> { // Whip
				float u = Mth.sin(swing * swing * Mth.PI);
				ry(p, side * 45f);
				rx(p, -105f * u * k);
				rz(p, side * -24f * u * k);
				ry(p, side * -45f);
			}
			case 8 -> { // Tap
				p.translate(0f, -0.14f * w * k, -0.22f * w * k);
				rx(p, -24f * w * k);
			}
			case 9 -> { // Hammer
				float a;
				if (swing < 0.4f) {
					a = -80f * Mth.sin(swing / 0.4f * Mth.HALF_PI);
				} else {
					float r = (swing - 0.4f) / 0.6f;
					a = -80f * (1f - Mth.sin(r * Mth.HALF_PI)) + 22f * Mth.sin(r * Mth.PI);
				}
				p.translate(0f, 0.12f * w * k, 0f);
				rx(p, a * k);
			}
			default -> {
				return false;
			}
		}
		return true;
	}

	/** Смещение и масштаб предмета в руке. */
	public static void applyOffset(PoseStack p, HumanoidArm arm) {
		if (!Modules.SWING.enabled) return;
		int side = arm == HumanoidArm.RIGHT ? 1 : -1;
		float x = Modules.SW_X.f(), y = Modules.SW_Y.f(), z = Modules.SW_Z.f();
		float sc = Modules.SW_SCALE.f();
		if (x != 0f || y != 0f || z != 0f) p.translate(side * x, y, z);
		if (sc != 1f) p.scale(sc, sc, sc);
	}
}
