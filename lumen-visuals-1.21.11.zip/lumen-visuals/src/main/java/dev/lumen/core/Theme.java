package dev.lumen.core;

import net.minecraft.util.Mth;

public final class Theme {
	public static final String[] NAMES = {"Violet", "Ocean", "Sunset", "Lime", "Ember", "Mono"};
	private static final int[][] PRESETS = {
		{0xFF8B5CF6, 0xFFD946EF},
		{0xFF22D3EE, 0xFF3B82F6},
		{0xFFF43F5E, 0xFFFB923C},
		{0xFFA3E635, 0xFF22C55E},
		{0xFFF59E0B, 0xFFEF4444},
		{0xFFE5E7EB, 0xFF9CA3AF}
	};

	public static final int TEXT = 0xFFF2F4F8;
	public static final int MUTED = 0xFF9AA3B2;
	public static final int GOOD = 0xFF4ADE80;
	public static final int WARN = 0xFFFBBF24;
	public static final int BAD = 0xFFF87171;

	private Theme() {}

	public static int accent() {
		return PRESETS[Modules.TH_ACCENT.mode][0];
	}

	public static int accent2() {
		return PRESETS[Modules.TH_ACCENT.mode][1];
	}

	public static int radius() {
		return Modules.TH_RADIUS.i();
	}

	/** Фон стеклянной панели с учётом прозрачности. */
	public static int bg(float alpha) {
		int a = Mth.clamp(Math.round(Modules.TH_OPACITY.f() * 255f * alpha), 0, 255);
		return (a << 24) | 0x0D1017;
	}
}
