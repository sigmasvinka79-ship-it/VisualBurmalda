package dev.lumen.core;

import java.util.Locale;

import net.minecraft.util.Mth;

/** Одна настройка модуля: переключатель, число или список режимов. */
public final class Setting {
	public enum Type { BOOL, NUM, MODE }

	public final String id, name;
	public final Type type;

	public boolean bool;
	public double num, min, max, step;
	public int mode;
	public String[] modes;

	/** Анимация в меню (0..1). */
	public float anim;

	private Setting(String id, String name, Type type) {
		this.id = id;
		this.name = name;
		this.type = type;
	}

	public static Setting bool(String id, String name, boolean def) {
		Setting s = new Setting(id, name, Type.BOOL);
		s.bool = def;
		s.anim = def ? 1f : 0f;
		return s;
	}

	public static Setting num(String id, String name, double def, double min, double max, double step) {
		Setting s = new Setting(id, name, Type.NUM);
		s.min = min;
		s.max = max;
		s.step = step;
		s.num = def;
		return s;
	}

	public static Setting mode(String id, String name, int def, String... modes) {
		Setting s = new Setting(id, name, Type.MODE);
		s.modes = modes;
		s.mode = def;
		return s;
	}

	public float f() {
		return (float) num;
	}

	public int i() {
		return (int) Math.round(num);
	}

	public String modeName() {
		return modes[mode];
	}

	public void cycle(int dir) {
		mode = Math.floorMod(mode + dir, modes.length);
	}

	public void setNum(double v) {
		v = Math.max(min, Math.min(max, v));
		if (step > 0) {
			v = Math.round(v / step) * step;
			v = Math.round(v * 10000.0) / 10000.0;
		}
		num = Math.max(min, Math.min(max, v));
	}

	public void setMode(int m) {
		mode = Mth.clamp(m, 0, modes.length - 1);
	}

	public String display() {
		return step >= 1 ? Integer.toString((int) Math.round(num)) : String.format(Locale.ROOT, "%.2f", num);
	}
}
