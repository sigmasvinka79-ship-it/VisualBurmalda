package dev.lumen.core;

public enum Category {
	HUD("HUD"),
	VISUALS("Visuals"),
	ANIMATIONS("Animations"),
	THEME("Theme");

	public final String label;

	Category(String label) {
		this.label = label;
	}
}
