package dev.lumen.core;

import java.util.ArrayList;
import java.util.List;

/** Реестр всех модулей и их настроек. */
public final class Modules {
	public static final List<Module> ALL = new ArrayList<>();

	private static Module reg(Module m) {
		ALL.add(m);
		return m;
	}

	// ───────────── HUD ─────────────
	public static final Module WATERMARK = reg(new Module("Watermark", "Name, FPS, ping and clock", Category.HUD, true, true));
	public static final Setting WM_FPS = WATERMARK.add(Setting.bool("fps", "Show FPS", true));
	public static final Setting WM_PING = WATERMARK.add(Setting.bool("ping", "Show ping", true));
	public static final Setting WM_TIME = WATERMARK.add(Setting.bool("time", "Show clock", true));

	public static final Module EFFECTS = reg(new Module("Effects", "Potion list with countdown timers", Category.HUD, true, true));
	public static final Setting EF_VANILLA = EFFECTS.add(Setting.bool("hide_vanilla", "Hide vanilla icons", true));
	public static final Setting EF_ICONS = EFFECTS.add(Setting.bool("icons", "Icons", true));
	public static final Setting EF_BAR = EFFECTS.add(Setting.bool("bar", "Progress bar", true));
	public static final Setting EF_FORMAT = EFFECTS.add(Setting.mode("format", "Time format", 0, "m:ss", "Seconds"));
	public static final Setting EF_WARN = EFFECTS.add(Setting.num("warn", "Blink below (sec)", 10, 0, 30, 1));

	public static final Module ARMOR = reg(new Module("Armor", "Armor pieces with durability", Category.HUD, true, true));
	public static final Setting AR_LAYOUT = ARMOR.add(Setting.mode("layout", "Layout", 0, "Vertical", "Horizontal"));
	public static final Setting AR_PCT = ARMOR.add(Setting.bool("percent", "Show percent", true));

	public static final Module TARGET = reg(new Module("Target HUD", "Info about the mob/player you look at", Category.HUD, true, true));
	public static final Setting TG_STYLE = TARGET.add(Setting.mode("style", "Style", 0, "Modern", "Minimal"));
	public static final Setting TG_ARMOR = TARGET.add(Setting.bool("armor", "Show armor", true));
	public static final Setting TG_DIST = TARGET.add(Setting.bool("distance", "Show distance", true));
	public static final Setting TG_LINGER = TARGET.add(Setting.num("linger", "Keep visible (sec)", 2, 0.5, 6, 0.5));

	public static final Module KEYS = reg(new Module("Keystrokes", "WASD, mouse buttons and CPS", Category.HUD, true, true));
	public static final Setting KS_MOUSE = KEYS.add(Setting.bool("mouse", "Mouse buttons", true));
	public static final Setting KS_SPACE = KEYS.add(Setting.bool("space", "Space bar", true));
	public static final Setting KS_CPS = KEYS.add(Setting.bool("cps", "Show CPS", true));

	public static final Module INFO = reg(new Module("Info", "Coordinates, speed and direction", Category.HUD, true, true));
	public static final Setting IN_COORDS = INFO.add(Setting.bool("coords", "Coordinates", true));
	public static final Setting IN_SPEED = INFO.add(Setting.bool("speed", "Speed", true));
	public static final Setting IN_DIR = INFO.add(Setting.bool("direction", "Direction", true));

	public static final Module ITEMS = reg(new Module("Item counter", "Totems, apples, pearls, crystals", Category.HUD, true, true));
	public static final Setting IT_TOTEM = ITEMS.add(Setting.bool("totem", "Totems", true));
	public static final Setting IT_GAPPLE = ITEMS.add(Setting.bool("gapple", "Golden apples", true));
	public static final Setting IT_PEARL = ITEMS.add(Setting.bool("pearl", "Ender pearls", true));
	public static final Setting IT_CRYSTAL = ITEMS.add(Setting.bool("crystal", "End crystals", false));
	public static final Setting IT_XP = ITEMS.add(Setting.bool("xp", "XP bottles", false));
	public static final Setting IT_HIDE = ITEMS.add(Setting.bool("hide_empty", "Hide empty", true));

	public static final Module NOTIFS = reg(new Module("Notifications", "Toasts when modules are toggled", Category.HUD, true, true));
	public static final Setting NF_TIME = NOTIFS.add(Setting.num("time", "Duration (sec)", 2.5, 1, 6, 0.5));

	// ───────────── Visuals ─────────────
	public static final Module CROSSHAIR = reg(new Module("Crosshair", "Custom crosshair with hit marker", Category.VISUALS, true, true));
	public static final Setting CH_STYLE = CROSSHAIR.add(Setting.mode("style", "Style", 0, "Cross", "Dot", "Circle", "T-Shape"));
	public static final Setting CH_COLOR = CROSSHAIR.add(Setting.mode("color", "Color", 0, "Accent", "White", "Rainbow"));
	public static final Setting CH_SIZE = CROSSHAIR.add(Setting.num("size", "Size", 4, 1, 12, 1));
	public static final Setting CH_GAP = CROSSHAIR.add(Setting.num("gap", "Gap", 2, 0, 10, 1));
	public static final Setting CH_THICK = CROSSHAIR.add(Setting.num("thickness", "Thickness", 1, 1, 4, 1));
	public static final Setting CH_DYNAMIC = CROSSHAIR.add(Setting.bool("dynamic", "Dynamic gap", true));
	public static final Setting CH_OUTLINE = CROSSHAIR.add(Setting.bool("outline", "Outline", true));
	public static final Setting CH_HIT = CROSSHAIR.add(Setting.bool("hitmarker", "Hit marker", true));

	// ───────────── Animations ─────────────
	public static final Module SWING = reg(new Module("Swing", "First-person swing animations", Category.ANIMATIONS, true, true));
	public static final Setting SW_MODE = SWING.add(Setting.mode("mode", "Animation", 1,
		"Vanilla", "Smooth", "Slash", "Slide", "Block", "Spin", "Poke", "Whip", "Tap", "Hammer"));
	public static final Setting SW_POWER = SWING.add(Setting.num("power", "Intensity", 1.0, 0.3, 2.0, 0.1));
	public static final Setting SW_SCALE = SWING.add(Setting.num("scale", "Item scale", 1.0, 0.4, 1.6, 0.05));
	public static final Setting SW_X = SWING.add(Setting.num("x", "Offset X", 0.0, -0.5, 0.5, 0.02));
	public static final Setting SW_Y = SWING.add(Setting.num("y", "Offset Y", 0.0, -0.5, 0.5, 0.02));
	public static final Setting SW_Z = SWING.add(Setting.num("z", "Offset Z", 0.0, -0.5, 0.5, 0.02));

	// ───────────── Theme ─────────────
	public static final Module THEME = reg(new Module("Interface", "Accent color and glass style", Category.THEME, true, false));
	public static final Setting TH_ACCENT = THEME.add(Setting.mode("accent", "Accent", 0, Theme.NAMES));
	public static final Setting TH_OPACITY = THEME.add(Setting.num("opacity", "Panel opacity", 0.72, 0.3, 1.0, 0.02));
	public static final Setting TH_RADIUS = THEME.add(Setting.num("radius", "Corner radius", 3, 0, 6, 1));

	private Modules() {}
}
