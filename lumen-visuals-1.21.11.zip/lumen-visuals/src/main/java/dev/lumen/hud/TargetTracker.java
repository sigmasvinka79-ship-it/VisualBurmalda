package dev.lumen.hud;

import net.minecraft.Util;
import net.minecraft.client.Minecraft;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.phys.EntityHitResult;

/**
 * Отслеживает существо под прицелом. Использует только ванильный hitResult
 * (то же, что видит игра), никакой дальности/подсветки сверх ванилы.
 */
public final class TargetTracker {
	public static LivingEntity entity;
	public static long lastSeen;
	public static long lastHit;
	private static LivingEntity prev;
	private static int prevHurt;

	private TargetTracker() {}

	public static void update(Minecraft mc) {
		long now = Util.getMillis();
		if (mc.hitResult instanceof EntityHitResult ehr
			&& ehr.getEntity() instanceof LivingEntity le
			&& le != mc.player && le.isAlive()) {
			entity = le;
			lastSeen = now;
		}
		LivingEntity e = entity;
		if (e == null) return;
		if (e == prev && e.hurtTime > prevHurt && mc.player != null && mc.player.swinging) {
			lastHit = now;
		}
		prev = e;
		prevHurt = e.hurtTime;
	}
}
