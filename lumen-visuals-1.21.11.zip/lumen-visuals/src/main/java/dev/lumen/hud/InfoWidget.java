package dev.lumen.hud;

import java.util.Locale;

import dev.lumen.core.Modules;
import dev.lumen.core.Theme;
import dev.lumen.util.Draw;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.core.Direction;
import net.minecraft.util.Mth;

public final class InfoWidget extends HudWidget {
	private long lastGt = -1;
	private float speed;
	private String coords = "", spd = "", dir = "";

	public InfoWidget() {
		super(Modules.INFO, 0.86f, 0.012f);
	}

	@Override
	protected void render(GuiGraphics g, float x, float y, float pt, int sw, int sh, float a) {
		Minecraft mc = Minecraft.getInstance();
		var p = mc.player;

		long gt = mc.level.getGameTime();
		if (gt != lastGt) {
			lastGt = gt;
			double sp = Math.hypot(p.getX() - p.xo, p.getZ() - p.zo) * 20.0;
			speed += (float) (sp - speed) * 0.35f;
			coords = Mth.floor(p.getX()) + " " + Mth.floor(p.getY()) + " " + Mth.floor(p.getZ());
			spd = String.format(Locale.ROOT, "%.1f b/s", speed);
			Direction d = p.getDirection();
			String n = d.getName();
			dir = Character.toUpperCase(n.charAt(0)) + n.substring(1) + " " + Math.round(Mth.wrapDegrees(p.getYRot())) + "\u00B0";
		}

		int rows = 0;
		float maxV = 0;
		if (Modules.IN_COORDS.bool) { rows++; maxV = Math.max(maxV, Draw.width(coords)); }
		if (Modules.IN_SPEED.bool) { rows++; maxV = Math.max(maxV, Draw.width(spd)); }
		if (Modules.IN_DIR.bool) { rows++; maxV = Math.max(maxV, Draw.width(dir)); }
		if (rows == 0) {
			w = 0;
			h = 0;
			return;
		}

		w = 10 + 24 + maxV + 10;
		h = rows * 11 + 7;
		Draw.panel(g, x, y, w, h, a);

		float cy = y + 5;
		if (Modules.IN_COORDS.bool) { row(g, x, cy, "XYZ", coords, a); cy += 11; }
		if (Modules.IN_SPEED.bool) { row(g, x, cy, "SPD", spd, a); cy += 11; }
		if (Modules.IN_DIR.bool) { row(g, x, cy, "DIR", dir, a); }
	}

	private static void row(GuiGraphics g, float x, float y, String label, String value, float a) {
		Draw.text(g, label, x + 8, y, 0.8f, Draw.a(Draw.lerp(Theme.accent(), Theme.accent2(), 0.4f), a), false);
		Draw.text(g, value, x + 8 + 24, y, Draw.a(Theme.TEXT, a));
	}
}
