package dev.lumen.hud;

import dev.lumen.core.Modules;
import dev.lumen.core.Theme;
import dev.lumen.util.Draw;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.util.Mth;
import net.minecraft.world.entity.EquipmentSlot;
import net.minecraft.world.item.ItemStack;

public final class ArmorWidget extends HudWidget {
	private static final EquipmentSlot[] SLOTS = {EquipmentSlot.HEAD, EquipmentSlot.CHEST, EquipmentSlot.LEGS, EquipmentSlot.FEET};
	private static final String[] PCT = new String[101];

	static {
		for (int i = 0; i <= 100; i++) PCT[i] = i + "%";
	}

	private final ItemStack[] stacks = new ItemStack[4];

	public ArmorWidget() {
		super(Modules.ARMOR, 0.90f, 0.40f);
	}

	@Override
	protected void render(GuiGraphics g, float x, float y, float pt, int sw, int sh, float a) {
		Minecraft mc = Minecraft.getInstance();
		boolean edit = HudRenderer.editing();
		boolean horiz = Modules.AR_LAYOUT.mode == 1;
		boolean pct = Modules.AR_PCT.bool;

		int n = 0;
		for (int i = 0; i < 4; i++) {
			stacks[i] = mc.player.getItemBySlot(SLOTS[i]);
			if (!stacks[i].isEmpty() || edit) n++;
		}
		if (n == 0) {
			w = 0;
			h = 0;
			return;
		}

		if (horiz) {
			w = n * 22 + 4;
			h = pct ? 38 : 29;
		} else {
			w = pct ? 84 : 56;
			h = n * 20 + 4;
		}
		Draw.panel(g, x, y, w, h, a);

		int k = 0;
		for (int i = 0; i < 4; i++) {
			ItemStack s = stacks[i];
			if (s.isEmpty() && !edit) continue;

			float ix = horiz ? x + 4 + k * 22 : x + 5;
			float iy = horiz ? y + 5 : y + 4 + k * 20 + 1;
			k++;

			if (s.isEmpty()) {
				Draw.rounded(g, ix - 1, iy - 1, 18, 18, 3, Draw.a(0xFFFFFFFF, 0.07f * a));
				continue;
			}
			if (a > 0.5f) g.renderItem(s, Math.round(ix), Math.round(iy));

			if (!s.isDamageableItem()) continue;
			float frac = 1f - (float) s.getDamageValue() / Math.max(1, s.getMaxDamage());
			int col = Draw.hp(frac);
			if (horiz) {
				Draw.bar(g, ix, iy + 19, 16, 2, frac, col, a);
				if (pct) {
					String t = PCT[Mth.clamp(Math.round(frac * 100f), 0, 100)];
					Draw.text(g, t, ix + 8 - Draw.width(t) * 0.6f / 2f, iy + 24, 0.6f, Draw.a(col, a), false);
				}
			} else {
				Draw.bar(g, ix + 22, iy + 7, 28, 3, frac, col, a);
				if (pct) {
					String t = PCT[Mth.clamp(Math.round(frac * 100f), 0, 100)];
					Draw.text(g, t, x + w - 5 - Draw.width(t) * 0.75f, iy + 5, 0.75f, Draw.a(Theme.MUTED, a), false);
				}
			}
		}
	}
}
