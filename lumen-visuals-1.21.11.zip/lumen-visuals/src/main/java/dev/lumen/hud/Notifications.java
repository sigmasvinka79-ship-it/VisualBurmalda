package dev.lumen.hud;

import java.util.ArrayList;
import java.util.List;

import dev.lumen.core.Modules;
import dev.lumen.core.Theme;
import dev.lumen.util.Anim;
import dev.lumen.util.Draw;
import net.minecraft.Util;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.util.Mth;

/** Уведомления справа снизу: выезжают с отскоком, стакаются, плавно исчезают. */
public final class Notifications {
	private static final class N {
		final String title;
		final boolean on;
		final long born = Util.getMillis();
		float y = -1f;

		N(String title, boolean on) {
			this.title = title;
			this.on = on;
		}
	}

	private static final List<N> LIST = new ArrayList<>();

	private Notifications() {}

	public static void push(String name, boolean on) {
		if (!Modules.NOTIFS.enabled) return;
		LIST.add(new N(name, on));
		while (LIST.size() > 5) LIST.remove(0);
	}

	public static void render(GuiGraphics g, int sw, int sh) {
		if (LIST.isEmpty()) return;
		long now = Util.getMillis();
		long life = (long) (Modules.NF_TIME.f() * 1000f);
		LIST.removeIf(q -> now - q.born > life + 350);

		float W = 124f, H = 26f;
		int k = 0;
		for (int i = LIST.size() - 1; i >= 0; i--) {
			N n = LIST.get(i);
			long age = now - n.born;
			float in = Anim.easeOutBack(age / 320f);
			float out = age > life ? Anim.smooth((age - life) / 320f) : 0f;

			float ty = sh - 12 - (k + 1) * (H + 5);
			n.y = n.y < 0f ? ty : Anim.approach(n.y, ty, 14f);
			float x = sw - W - 10 + (1f - in) * (W + 20) + out * (W + 20);
			float al = 1f - out * 0.6f;

			Draw.panel(g, x, n.y, W, H, al);
			Draw.rounded(g, x + 7, n.y + 9, 8, 8, 4, Draw.a(n.on ? Theme.GOOD : Theme.BAD, al));
			Draw.text(g, n.title, x + 22, n.y + 5, Draw.a(Theme.TEXT, al));
			Draw.text(g, n.on ? "Enabled" : "Disabled", x + 22, n.y + 15, 0.75f, Draw.a(Theme.MUTED, al), false);

			float frac = 1f - Mth.clamp(age / (float) Math.max(1L, life), 0f, 1f);
			int bx = Math.round(x + 5), by = Math.round(n.y + H - 3);
			g.fill(bx, by, bx + Math.round((W - 10) * frac), by + 1, Draw.a(Theme.accent(), al));
			k++;
		}
	}
}
