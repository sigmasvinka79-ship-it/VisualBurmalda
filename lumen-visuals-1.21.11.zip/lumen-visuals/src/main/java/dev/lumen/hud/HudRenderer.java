package dev.lumen.hud;

import java.util.ArrayList;
import java.util.List;

import dev.lumen.LumenClient;
import dev.lumen.core.Module;
import dev.lumen.core.Modules;
import dev.lumen.core.Theme;
import dev.lumen.gui.MenuScreen;
import dev.lumen.util.Anim;
import dev.lumen.util.Draw;
import dev.lumen.util.Stats;
import net.fabricmc.fabric.api.client.rendering.v1.hud.HudElementRegistry;
import net.fabricmc.fabric.api.client.rendering.v1.hud.VanillaHudElements;
import net.minecraft.client.DeltaTracker;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.resources.Identifier;
import org.joml.Matrix3x2fStack;

public final class HudRenderer {
	private static final List<HudWidget> WIDGETS = new ArrayList<>();

	private HudRenderer() {}

	public static List<HudWidget> widgets() {
		return WIDGETS;
	}

	public static boolean editing() {
		return Minecraft.getInstance().screen instanceof MenuScreen;
	}

	public static void init() {
		WIDGETS.add(new WatermarkWidget());
		WIDGETS.add(new EffectsWidget());
		WIDGETS.add(new ArmorWidget());
		WIDGETS.add(new TargetWidget());
		WIDGETS.add(new KeystrokesWidget());
		WIDGETS.add(new InfoWidget());
		WIDGETS.add(new ItemsWidget());

		HudElementRegistry.addLast(Identifier.fromNamespaceAndPath(LumenClient.ID, "overlay"), HudRenderer::render);

		// Подмена ванильных элементов. Имена констант ищем рефлексией, чтобы сборка
		// не ломалась, если в твоей версии Fabric API они названы чуть иначе.
		Identifier cross = vanilla("CROSSHAIR");
		if (cross != null) {
			HudElementRegistry.replaceElement(cross, prev -> (g, dt) -> {
				if (Modules.CROSSHAIR.enabled) CrosshairRenderer.render(g);
				else prev.render(g, dt);
			});
		}
		Identifier fx = vanilla("STATUS_EFFECTS", "MOB_EFFECTS");
		if (fx != null) {
			HudElementRegistry.replaceElement(fx, prev -> (g, dt) -> {
				if (!(Modules.EFFECTS.enabled && Modules.EF_VANILLA.bool)) prev.render(g, dt);
			});
		}
	}

	private static Identifier vanilla(String... names) {
		for (String n : names) {
			try {
				return (Identifier) VanillaHudElements.class.getField(n).get(null);
			} catch (Throwable ignored) {
			}
		}
		return null;
	}

	public static void render(GuiGraphics g, DeltaTracker dt) {
		Minecraft mc = Minecraft.getInstance();
		if (mc.player == null || mc.level == null) return;

		Anim.tick();
		Stats.frame();
		TargetTracker.update(mc);

		int sw = g.guiWidth(), sh = g.guiHeight();
		float pt = dt.getGameTimeDeltaPartialTick(false);
		boolean edit = mc.screen instanceof MenuScreen;

		for (HudWidget w : WIDGETS) {
			Module m = w.module;
			m.vis = Anim.approach(m.vis, m.enabled ? 1f : 0f, 14f);
			if (m.vis < 0.02f) {
				w.w = 0;
				w.h = 0;
				continue;
			}
			Matrix3x2fStack ps = g.pose();
			ps.pushMatrix();
			ps.translate(0f, (1f - m.vis) * -5f);
			w.draw(g, pt, sw, sh, m.vis);
			ps.popMatrix();

			if (edit && w.w > 0) {
				boolean drag = mc.screen instanceof MenuScreen ms && ms.draggingWidget() == w;
				g.renderOutline(Math.round(w.px) - 2, Math.round(w.py) - 2, Math.round(w.w) + 4, Math.round(w.h) + 4,
					drag ? Draw.a(Theme.accent(), 0.95f) : Draw.a(0xFFFFFFFF, 0.28f));
			}
		}
		Notifications.render(g, sw, sh);
	}
}
