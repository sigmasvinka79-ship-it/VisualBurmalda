package dev.lumen.hud;

import dev.lumen.core.Modules;
import dev.lumen.core.Theme;
import dev.lumen.util.Anim;
import dev.lumen.util.Draw;
import net.minecraft.Util;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.util.Mth;

/** Кастомный прицел: 4 стиля, динамический зазор (кулдаун/движение), хитмаркер. */
public final class CrosshairRenderer {
	private static float dyn;

	private CrosshairRenderer() {}

	private static int color() {
		return switch (Modules.CH_COLOR.mode) {
			case 1 -> 0xFFFFFFFF;
			case 2 -> 0xFF000000 | Mth.hsvToRgb((Util.getMillis() % 4000L) / 4000f, 0.65f, 1f);
			default -> Theme.accent();
		};
	}

	private static void box(GuiGraphics g, int x1, int y1, int x2, int y2, int col, boolean outlinePass) {
		if (outlinePass) g.fill(x1 - 1, y1 - 1, x2 + 1, y2 + 1, 0xB0000000);
		else g.fill(x1, y1, x2, y2, col);
	}

	public static void render(GuiGraphics g) {
		Minecraft mc = Minecraft.getInstance();
		var p = mc.player;
		if (p == null) return;

		int cx = g.guiWidth() / 2, cy = g.guiHeight() / 2;
		int size = Modules.CH_SIZE.i(), t = Modules.CH_THICK.i();
		int style = Modules.CH_STYLE.mode;

		float target = 0f;
		if (Modules.CH_DYNAMIC.bool) {
			target = (1f - p.getAttackStrengthScale(0f)) * 4f;
			if (p.getDeltaMovement().horizontalDistanceSqr() > 0.0004) target += 1.5f;
			if (p.isSprinting()) target += 1f;
		}
		dyn = Anim.approach(dyn, target, 14f);
		int gp = Modules.CH_GAP.i() + Math.round(dyn);

		int col = color();
		int half = t / 2;
		boolean outline = Modules.CH_OUTLINE.bool;

		for (int pass = outline ? 0 : 1; pass < 2; pass++) {
			boolean o = pass == 0;
			int x0 = cx - half, y0 = cy - half;
			switch (style) {
				case 1 -> {
					int d = Math.max(2, t + 1);
					int dx = cx - d / 2, dy = cy - d / 2;
					box(g, dx, dy, dx + d, dy + d, col, o);
				}
				case 2 -> {
					int r = gp + size / 2 + 2;
					int n = Math.max(20, r * 5);
					for (int i = 0; i < n; i++) {
						double ang = Math.PI * 2.0 * i / n;
						int px = cx + (int) Math.round(Math.cos(ang) * r) - half;
						int py = cy + (int) Math.round(Math.sin(ang) * r) - half;
						box(g, px, py, px + t, py + t, col, o);
					}
				}
				default -> {
					// left / right / bottom, top отсутствует у T-Shape
					box(g, x0 - gp - size, y0, x0 - gp, y0 + t, col, o);
					box(g, x0 + t + gp, y0, x0 + t + gp + size, y0 + t, col, o);
					box(g, x0, y0 + t + gp, x0 + t, y0 + t + gp + size, col, o);
					if (style == 0) box(g, x0, y0 - gp - size, x0 + t, y0 - gp, col, o);
				}
			}
		}

		if (Modules.CH_HIT.bool) {
			long age = Util.getMillis() - TargetTracker.lastHit;
			if (age >= 0 && age < 320) {
				float al = 1f - age / 320f;
				int hc = Draw.a(0xFFFFFFFF, al);
				int d0 = 3 + (int) (age / 80);
				for (int sx = -1; sx <= 1; sx += 2) {
					for (int sy = -1; sy <= 1; sy += 2) {
						for (int i = 0; i < 4; i++) {
							int ox = cx + sx * (d0 + i), oy = cy + sy * (d0 + i);
							g.fill(ox, oy, ox + 1, oy + 1, hc);
						}
					}
				}
			}
		}
	}
}
