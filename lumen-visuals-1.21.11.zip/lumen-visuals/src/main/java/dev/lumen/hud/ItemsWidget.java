package dev.lumen.hud;

import dev.lumen.core.Modules;
import dev.lumen.core.Setting;
import dev.lumen.core.Theme;
import dev.lumen.util.Draw;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;

/** Счётчик расходников в инвентаре (тотемы, яблоки, жемчуг...). */
public final class ItemsWidget extends HudWidget {
	private ItemStack[] icons;
	private final int[] counts = new int[5];
	private final String[] texts = {"0", "0", "0", "0", "0"};
	private long lastGt = -1;

	public ItemsWidget() {
		super(Modules.ITEMS, 0.42f, 0.012f);
	}

	@Override
	protected void render(GuiGraphics g, float x, float y, float pt, int sw, int sh, float a) {
		Minecraft mc = Minecraft.getInstance();
		if (icons == null) {
			icons = new ItemStack[] {
				new ItemStack(Items.TOTEM_OF_UNDYING),
				new ItemStack(Items.GOLDEN_APPLE),
				new ItemStack(Items.ENDER_PEARL),
				new ItemStack(Items.END_CRYSTAL),
				new ItemStack(Items.EXPERIENCE_BOTTLE)
			};
		}
		long gt = mc.level.getGameTime();
		if (gt != lastGt) {
			lastGt = gt;
			for (int i = 0; i < counts.length; i++) counts[i] = 0;
			var inv = mc.player.getInventory();
			for (int i = 0; i < inv.getContainerSize(); i++) {
				ItemStack s = inv.getItem(i);
				if (s.isEmpty()) continue;
				int c = s.getCount();
				if (s.is(Items.TOTEM_OF_UNDYING)) counts[0] += c;
				else if (s.is(Items.GOLDEN_APPLE) || s.is(Items.ENCHANTED_GOLDEN_APPLE)) counts[1] += c;
				else if (s.is(Items.ENDER_PEARL)) counts[2] += c;
				else if (s.is(Items.END_CRYSTAL)) counts[3] += c;
				else if (s.is(Items.EXPERIENCE_BOTTLE)) counts[4] += c;
			}
			for (int i = 0; i < counts.length; i++) texts[i] = Integer.toString(counts[i]);
		}

		Setting[] on = {Modules.IT_TOTEM, Modules.IT_GAPPLE, Modules.IT_PEARL, Modules.IT_CRYSTAL, Modules.IT_XP};
		boolean hide = Modules.IT_HIDE.bool, edit = HudRenderer.editing();

		float total = 6;
		int shown = 0;
		for (int i = 0; i < on.length; i++) {
			if (!on[i].bool || (hide && counts[i] == 0 && !edit)) continue;
			total += 20 + Draw.width(texts[i]) + 8;
			shown++;
		}
		if (shown == 0) {
			w = 0;
			h = 0;
			return;
		}
		w = total;
		h = 24;
		Draw.panel(g, x, y, w, h, a);

		float cx = x + 6;
		for (int i = 0; i < on.length; i++) {
			if (!on[i].bool || (hide && counts[i] == 0 && !edit)) continue;
			if (a > 0.5f) g.renderItem(icons[i], Math.round(cx), Math.round(y) + 4);
			int col = counts[i] == 0 ? Theme.MUTED : Theme.TEXT;
			Draw.text(g, texts[i], cx + 18, y + 8, Draw.a(col, a));
			cx += 20 + Draw.width(texts[i]) + 8;
		}
	}
}
